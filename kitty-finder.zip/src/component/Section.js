import Items from "./Items";
import Search from "./Search";
import classes from "./Section.module.css"

function Section(){
    return(
        <div className={classes.layout}>
            <div>
                <Search/>
            </div>
            <div>
                <Items/>
            </div>
        </div>
    )

}

export default Section;