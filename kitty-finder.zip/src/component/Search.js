import {FaSearch} from 'react-icons/fa'
import classes from './Search.module.css'

function Search(){
    return(
        <div className={classes.searchBox}>
            <span className={classes.icon}><FaSearch/> </span>
            <input className={classes.input} type="search" placeholder="search by name"></input>
        </div>
    )

}

export default Search;
