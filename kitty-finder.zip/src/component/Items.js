import InfoList from "../component/catsInfo/InfoList"
import classes from "./Item.module.css"
const CATS=[
    {
        id:'1',
        image:'https://robohash.org/${1}?set=set4',
        owner:'owner: Leanne Graham',
        username:'Username: Bret',
        email:'Email: Sincere@april.biz'
    },
    {
        id:'2',
        image:'https://robohash.org/${2}?set=set4',
        owner:'owner: Ervin Howell',
        username:'Username: Antonette',
        email:'Email: Shanna@melissa.tv'
    },
    {
        id:'3',
        image:'https://robohash.org/${3}?set=set4',
        owner:'owner: Clementine Bauch',
        username:'Username: Samantha',
        email:'Email: Nathan@yesenia.net'
    },
    {
        id:'4',
        image:'https://robohash.org/${4}?set=set4',
        owner:'owner: Patricia Lebsack',
        username:'Username:Karianne',
        email:'Email: Julianne.OConner@kory.org'
    },
    {
        id:'5',
        image:'https://robohash.org/${5}?set=set4',
        owner:'owner: Chelsey Dietrich',
        username:'Username: Kamren',
        email:'Email: Lucio_Hettinger@annie.ca'
    },
    {
        id:'6',
        image:'https://robohash.org/${6}?set=set4',
        owner:'owner: Mrs. Dennis Schulist',
        username:'Username: Leopoldo_Corkery',
        email:'Email: Karley_Dach@jasper.info'
    },
    {
        id:'7',
        image:'https://robohash.org/${7}?set=set4',
        owner:'owner: Kurtis Weissnat',
        username:'Username: Elwyn.Skiles',
        email:'Email: Telly.Hoeger@billy.biz'
    },
    {
        id:'8',
        image:'https://robohash.org/${8}?set=set4',
        owner:'owner: Nicholas Runolfsdottir V',
        username:'Username: Maxime_Nienow',
        email:'Email: Sherwood@rosamond.me'
    },
    {
        id:'9',
        image:'https://robohash.org/${9}?set=set4',
        owner:'owner: Glenna Reichert',
        username:'Username: Delphine',
        email:'Email: Chaim_McDermott@dana.io'
    },
    {
        id:'10',
        image:'https://robohash.org/${10}?set=set4',
        owner:'owner: Clementina DuBuque',
        username:'Username: Moriah.Stanton',
        email:'Email: Rey.Padberg@karina.biz'
    },

]
        

function Items (){
    return(
        <div className={classes.cards}>
            <InfoList cats={CATS} />            
        </div>
    )
}

export default Items;