import classes from "./Info.module.css"
function Info(props){
    return(
        <li className={classes.card}>
            <div>
                <img src={props.image} alt={props.owner} className={classes.image}/>
            </div>
            <div className={classes.text}>
                <p>{props.owner}</p>
                <p>{props.username}</p>
                <p>{props.email}</p>
            </div>
        </li>
    )
}

export default Info