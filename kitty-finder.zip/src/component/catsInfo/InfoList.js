import Info from "./Info";
import classes from "./InfoList.module.css"
function InfoList(props){
    return(
        <ul className={classes.cards}>
            {props.cats.map(cat =>
                <Info 
                key={cat.id}
                id={cat.id}
                image={cat.image}
                owner={cat.owner}
                username={cat.username}
                email={cat.email}
                />
            )}
        </ul>
    )
}

export default InfoList;