import Button from "./Button";
import Header from "./Header";
import classes from "./Head.module.css"

function Head(){
    return(
        <div className={classes.back}>
            <Header title="KITTY FINDER"/>
            <div className={classes.find}>
                <div className={classes.texts}>
                    <p className={classes.text1}>SEARCH AND FIND</p>
                    <p className={classes.text2} >YOUR KITTY </p>
                    <Button text="Start searching"/>
                </div>
                <div>
                    <img src="/assets/Cat1.png" alt="cat1"/>
                    <img src="/assets/Cat2.png" alt="cat2" />
                </div>

            </div>
        </div>
    )
}

export default Head;