import Head from './component/Head'
import Section from './component/Section';

function App() {

  return (
    <div>
      <Head/>
      <Section/>
    </div>
  )

}

export default App;
